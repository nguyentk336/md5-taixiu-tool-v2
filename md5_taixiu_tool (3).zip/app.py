import streamlit as st
import hashlib
import pandas as pd

st.set_page_config(page_title="Dự đoán Tài/Xỉu từ MD5", layout="centered")
st.title("🔐 Dự đoán Tài/Xỉu từ chuỗi MD5 (Tỷ số)")
st.markdown("""
- Nhập chuỗi MD5 tương ứng với tỷ số dạng `x-y` (ví dụ: `2-1`)
- Chọn ngưỡng Tài/Xỉu (ví dụ: 2.5)
- Xem kết quả dự đoán Tài hoặc Xỉu dựa trên tổng bàn
- Hoặc tải lên file TXT nhiều chuỗi MD5 (mỗi dòng 1 mã)
""")

nguong = st.selectbox("Chọn ngưỡng Tài/Xỉu", [2.5, 3.5, 4.5], index=0)

def md5(text):
    return hashlib.md5(text.encode()).hexdigest()

def giai_ma_md5(md5_input, nguong=2.5):
    # dò từ tổng bàn 0 đến 30
    for tong in range(0, 31):
        for i in range(tong + 1):
            ty_so = f"{i}-{tong - i}"
            if md5(ty_so) == md5_input:
                ket_qua = "Tài" if tong > nguong else "Xỉu"
                return ty_so, tong, ket_qua
    return None, None, None

md5_input = st.text_input("📥 Nhập chuỗi MD5 đơn", "")

if md5_input:
    ty_so, tong_ban, ket_qua = giai_ma_md5(md5_input.strip(), nguong)
    if ty_so:
        st.success(f"✅ Tỷ số: `{ty_so}` | Tổng bàn: `{tong_ban}` | 📊 Kết quả: **{ket_qua}**")
    else:
        st.error("⛔ Không tìm thấy tỷ số phù hợp.")

st.markdown("### 📄 Hoặc tải lên file danh sách MD5 (.txt)")

uploaded_file = st.file_uploader("Chọn file TXT", type=["txt"])

if uploaded_file:
    content = uploaded_file.read().decode("utf-8")
    lines = [line.strip() for line in content.strip().split("\n") if line.strip()]
    
    results = []
    for line in lines:
        ty_so, tong_ban, ket_qua = giai_ma_md5(line, nguong)
        results.append({
            "MD5": line,
            "Tỷ số": ty_so or "Không tìm thấy",
            "Tổng bàn": tong_ban if tong_ban is not None else "-",
            "Kết quả": ket_qua or "-"
        })
    
    df = pd.DataFrame(results)
    st.dataframe(df, use_container_width=True)

    csv = df.to_csv(index=False).encode("utf-8")
    st.download_button("📥 Tải kết quả CSV", csv, "ket_qua_du_doan.csv", "text/csv")
